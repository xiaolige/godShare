
public class FractalData {

    private int depth;

    public FractalData(int depth){
        this.depth = depth;
    }

    public int getDepth(){
        return depth;
    }
}

package com.luna.quart.config;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QuartzConfig {

	Logger logger = LoggerFactory.getLogger(QuartzConfig.class);
	
	@Bean
	public Scheduler getScheduler() {
		Scheduler scheduler=null;
		   try {
			scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.start();
		} catch (SchedulerException e) {
			logger.debug(e.getLocalizedMessage());
		}
		   return scheduler;
	}
}

package com.luna.quart.result;

public interface Constants {

	public static String SUCCESS="success";
	public static String FAILURE="failure";
}

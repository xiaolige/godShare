package com.luna.quart.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.websocket.server.PathParam;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.luna.quart.domain.JobDomain;
import com.luna.quart.job.CreateJob;
import com.luna.quart.mapper.QuartzDao;
import com.luna.quart.result.Constants;
import com.luna.quart.result.Result;

@RestController
public class QuartzController {
	Logger logger = LoggerFactory.getLogger(QuartzController.class);

	@Autowired
	private QuartzDao  quartzDao;
	@Autowired
	private Scheduler scheduler;
	
	@PostMapping("/quartzs")
	public  Result addQuartzJob(@RequestBody JobDomain jobDomain) {
		Result result = new Result();
		logger.info("add quartz job start");
		String jobId=UUID.randomUUID().toString().replaceAll("-", "");
		jobDomain.setJobName(jobId);
		
		try {
			JobDetail job = JobBuilder.newJob(CreateJob.class)
					.storeDurably()
			     .withIdentity(jobId, jobDomain.getGroup())
			     .build();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date startDate=sdf.parse(jobDomain.getCycle()+" "+jobDomain.getTime());
		 SimpleTrigger trigger = TriggerBuilder.newTrigger().startAt(startDate)
			           .withSchedule(SimpleScheduleBuilder.simpleSchedule()
			        		   .withIntervalInSeconds(4)
                                .repeatForever()
			               ).build();
		 scheduler.scheduleJob(job, trigger);
		quartzDao.addJob(jobDomain);
		result.setStatus(Constants.SUCCESS);
		}catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Constants.FAILURE);
		}
		logger.info("add quartz job end,jobName :"+jobId);
		
		return result;
		
	}
	@DeleteMapping("/quartzs/{jobId}")
	public  Result delQuartzJob(@PathVariable("jobId")String jobName) {
		Result result = new Result();
		logger.info("del quartz job start,jobName "+jobName);
		
		try {
		 scheduler.deleteJob(new JobKey(jobName,"xiao"));
		quartzDao.delJob(jobName);
		result.setStatus(Constants.SUCCESS);
		}catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Constants.FAILURE);
		}
		logger.info("del quartz job end,jobName :"+jobName);
		return result;
		
	}
	@GetMapping("/quartzs/stop/{jobId}")
	public  Result stopQuartzJob(@PathVariable("jobId")String jobName) {
		Result result = new Result();
		logger.info("stop quartz job start,jobName "+jobName);
		
		try {
		 scheduler.pauseJob(new JobKey(jobName,"xiao"));
		result.setStatus(Constants.SUCCESS);
		}catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Constants.FAILURE);
		}
		logger.info("stop quartz job success,jobName :"+jobName);
		return result;
		
	}
	@GetMapping("/quartzs/resume/{jobId}")
	public  Result resumeQuartzJob(@PathVariable("jobId")String jobName) {
		Result result = new Result();
		logger.info("resume quartz job start,jobName "+jobName);
		
		try {
		 scheduler.resumeJob(new JobKey(jobName,"xiao"));
		result.setStatus(Constants.SUCCESS);
		}catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Constants.FAILURE);
		}
		logger.info("resume quartz job success,jobName :"+jobName);
		return result;
		
	}
}

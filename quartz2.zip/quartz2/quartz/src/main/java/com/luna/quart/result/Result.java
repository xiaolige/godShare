package com.luna.quart.result;

import java.io.Serializable;

public class Result implements Serializable{

	private String status;
	private Object target;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Object getTarget() {
		return target;
	}
	public void setTarget(Object target) {
		this.target = target;
	}
}

package com.luna.quart.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreateJob implements  Job{
	Logger logger = LoggerFactory.getLogger(CreateJob.class);

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobKey jobKey = context.getJobDetail().getKey();
		logger.info(jobKey.getName()+"start create job, belong "+jobKey.getGroup());
	}

}

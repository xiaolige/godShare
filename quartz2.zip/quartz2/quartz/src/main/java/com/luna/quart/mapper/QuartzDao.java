package com.luna.quart.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;

import com.luna.quart.domain.JobDomain;

public interface QuartzDao {

	@Insert("INSERT INTO job(job_name,`group`,cycle,`time`) "
			+ "VALUES(#{jobName},#{group},#{cycle},#{time})")
	public void addJob(JobDomain job);

	@Delete("DELETE FROM job WHERE  job_name=#{jobName}")
	public void delJob(String jobName);
}
